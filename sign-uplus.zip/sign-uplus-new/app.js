// app.js
var Right = "1"
var Sign = "1"
var People = "people"
var Place = "place"
var Time = "time"
var OpenID = "0"
var CompanyID = "0"
var ID = "0"
var Fake = "1"
var Latitude_1="0"
var Longitude_1="0"
var Latitude_2="0"
var Longitude_2="0"
App({

  globalData:{
    Right: Right,
    Sign:Sign,
    People:People,
    Place:Place,
    Time:Time,
    OpenID:OpenID,
    CompanyID:CompanyID,
    ID:ID,
    Latitude_1:Latitude_1,
    Longitude_1:Longitude_1,
    Latitude_2:Latitude_2,
    Longitude_2:Longitude_2
  },
  onLaunch(){
    wx.cloud.init({
      env:'cloud1-2gopeskg7385ef5c',
      traceUser: true,
    })
  }





})

// pages/login/login.js
var app = getApp();
var db = wx.cloud.database();
var Right = app.globalData.Right;
var CompanyID = app.globalData.CompanyID;
var Sign = app.globalData.Sign;
var ID = app.globalData.ID;
var Latitude_1=app.globalData.Latitude_1;
var Longitude_1 = app.globalData.Longitude_1;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    OpenID:"",
    Password:"",
    openID:"",
    password:"",
    Obj:"",
    Sign:"",
    ID:"",
    Location_mas:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },

  go_to_register(){
    wx.navigateTo({
      url: '/pages/Register_staff/Register_staff',
    })
  },

  go_to_Company(){
    wx.navigateTo({
      url: '/pages/Register_company/Register_company',
    })
  },


  inputOpenID:function (e) {
   
    var that = this
    
    that.setData({
      OpenID:e.detail.value
    })
    console.log("OpenID:"+that.data.OpenID)
  },

  inputPassword:function (e) {
    var that = this
    that.setData({
      Password:e.detail.value
      
    })

    console.log("Password:"+that.data.Password)
    
  },

  login(){
    var that = this
    that.setData({
      openID:that.data.OpenID,
      password:that.data.Password
    })
    db.collection("OpenID").where({
      OpenID:that.data.OpenID,
      Password:that.data.Password
    }).get()
    .then(res=>{
      
      that.setData({
        Obj:res.data

      })
      
      app.globalData.OpenID = that.data.Obj[0].OpenID
      app.globalData.Right=that.data.Obj[0].Right
      app.globalData.CompanyID = that.data.Obj[0].CompanyID
      app.globalData.Sign = that.data.Obj[0].Sign
      app.globalData.ID = that.data.Obj[0]._id

      if(that.data.Obj[0].Right==2||that.data.Obj[0].Right==1){
        wx.switchTab({
          url: '/pages/sign-in/sign-in',
        })
      }else if(that.data.Obj[0].Right==3)
      {
        wx.navigateTo({
          url: '/pages/staff_list_Entry/staff_list_Entry',
        })
      }
    }).catch(err=>{
      wx.showModal({
        title: 'Wrong',
        content: 'Wrong OpenID or Password',
        complete: (res) => {
          if (res.cancel) {
            
          }
      
          if (res.confirm) {
            
          }
        }
      })
    }).then(res=>{
      var thatdata = this
      db.collection("location").where({
        CompanyID:app.globalData.CompanyID
      }).get().then(res=>{
        thatdata.setData({
          Location_mas:res.data
        })
        
        app.globalData.Latitude_1 = thatdata.data.Location_mas[0].Latitude
        app.globalData.Longitude_1 = thatdata.data.Location_mas[0].Longitude
      })
    })
    

    
    
    
  }

})
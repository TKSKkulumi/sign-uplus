// pages/Register_company/Register_company.js
var db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    OpenID_1st: "",
    Password_1st: "",
    OpenID_2nd: "",
    Password_2nd: "",
    Company_Name: "",
    companyID: "0"
  },

  addData(res) {
    var that = this
    var thatres=res
    console.log(res)
    db.collection("CompanyID").count({
      success: function (res) {
        that.setData({
          companyID: res.total + 1
        }, () => {
          var { OpenID_1st, Password_1st, OpenID_2nd, Password_2nd, Company_Name } = thatres.detail.value;
          console.log("ID3" + that.data.companyID)
          db.collection("CompanyID").add({

            data: {
              CompanyID: that.data.companyID,
              Company_Name: Company_Name
            }
          })
          db.collection("OpenID").add({
            data: {
              OpenID: OpenID_1st,
              Password: Password_1st,
              CompanyID: that.data.companyID,
              Right:"3",
              Sign:"2"
            }
          }).then(res => {
            console.log(res)
          })
          db.collection("OpenID").add({
            data: {
              OpenID: OpenID_2nd,
              Password: Password_2nd,
              CompanyID: that.data.companyID,
              Right:"3",
              Sign:"2"
            }
          }).then(res => {
            console.log(res)
          })
        })
        console.log("ID:" + that.data.companyID)

      }
    })


  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }


})
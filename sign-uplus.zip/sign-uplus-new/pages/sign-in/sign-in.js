// pages/sign-in/sign-in.js
var app = getApp()
const db = wx.cloud.database()
var Sign = app.globalData.Sign
var Fake = app.globalData.Fake
var Latitude_1 = app.globalData.Latitude_1
var Longitude_1 = app.globalData.Longitude_1
var Latitude_2 = app.globalData.Latitude_2
var Longitude_2 = app.globalData.Longitude_2
Page({

  /**
   * 页面的初始数据
   */

  data: {
    signOBJ:"You have not completed your sign-in",
    Distance:"You have entered the attendance range",
    Address:"",
    distance:""
    
  },
  sign_in(){
    var that = this
    // db.collection("OpenID").doc("app.globalData.ID").update({
    //   data:{
    //     Sign:"2"
    //   }
    // }).then(res=>{
    //   console.log(res)
    //   console.log("执行了")
    // })
    app.globalData.Sign="2"
    that.onLoad()
    
  },
  onShow:function() {
    const pages = getCurrentPages()
    const perpage = pages[pages.length-1]
    perpage.onLoad()
  },
/**
   * 生命周期函数--监听页面加载
   */
  onLoad() {
    var that = this

    wx.getLocation({
      type:'gcj02',
      success:(res)=>{
        console.log(app.globalData.Latitude_1)
        console.log(app.globalData.Longitude_1)
        var distance = that.distance(res.latitude, res.longitude,
          app.globalData.Latitude_1,app.globalData.Longitude_1);
        that.setData({
          distance:distance
        })
        console.log("当前位置:", that.distance)
      }
    },()=>{
      if(that.distance<=100){
        that.setData({
          Distance:"You have entered the attendance range"
        })
      }else if(that.distance>100){
        that.setData({
          Distance:"You are not in the attendance range"
        })
      }
    })

    if(app.globalData.Sign==1){
      that.setData({
        signOBJ:"You have not completed sign-in"
      })
    }else if(app.globalData.Sign==2){
      that.setData({
        signOBJ:"You have signed in"
      })
    }
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  distance: function (la1, lo1, la2, lo2) {
    var La1 = la1 * Math.PI / 180.0;
    var La2 = la2 * Math.PI / 180.0;
    var La3 = La1 - La2;
    var Lb3 = lo1 * Math.PI / 180.0 - lo2 * Math.PI / 180.0;
    var s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(La3 / 2), 2) + Math.cos(La1) * Math.cos(La2) * Math.pow(Math.sin(Lb3 / 2), 2)));
    s = s * 6378.137;
    s = Math.round(s * 10000) / 10000;
    s = s.toFixed(2);
    return s;
  },

  















})
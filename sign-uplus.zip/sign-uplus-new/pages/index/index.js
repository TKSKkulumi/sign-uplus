// index.js
Page({
  onShow:function () {
    setTimeout(() => {
      wx.navigateTo({
        url: '/pages/login/login',
      })

    }, 2000);
  }
})

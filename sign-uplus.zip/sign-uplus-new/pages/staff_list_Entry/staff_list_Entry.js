// pages/staff_list_Entry/staff_list_Entry.js
var app = getApp();
var db = wx.cloud.database();

var CompanyID = app.globalData.CompanyID;
Page({

  /**
   * 页面的初始数据
   */
  data: {
    CompanyID:"",
    OpenID:"",
    staffName:"",
    staffLimits:""
  },

  /**
   * 生命周期函数--监听页面加载
   */


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  },
  addData(res){
    var that = this;
    var { staffName, staffLimits } = res.detail.value;
    db.collection("staff").add({

      data: {
        CompanyID: app.globalData.CompanyID,
        Name:staffName,
        Limits:staffLimits,
        OpenID:that.data.OpenID
      }
    })
    wx.showToast({
      title: 'success',
    })

  },
  setLocation(){
    wx.navigateTo({
      url: '/pages/setLocation/setLocation',
    })
  },
  get_OpenID(){
    var that = this
    db.collection("staff").where({
      CompanyID: app.globalData.CompanyID
    }).count({
      success: function (res) {
        var total = res.total+1
        console.log(total)
        that.setData({
            OpenID:app.globalData.CompanyID+total
          })
    // .then(res=>{
    //   var total = res.total+1
    //   console.log(total)
      // that.setData({
      //   OpenID:app.globalData.CompanyID+total
      // })
      }
    })
  },

  getID(){
    var that = this
    that.setData({
      nullHouse:false,
      CompanyID:app.globalData.CompanyID
    })
  }
})